import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main extends JFrame {

    private JTabbedPane mainTabbedPane;
    private JTabbedPane employeesTabbedPane;
    private JTable purchaseinfoTable;
    private JTable currentstockTable;
    private JTable customersTable;
    

    public Main() {
        initializeUI();
        fetchInitialDataFromDatabase();
    }

    private void fetchInitialDataFromDatabase() {
		// Fetch initial data for tables from the database and update table models
        fetchpurchaseinfoDataFromDatabase((DefaultTableModel) purchaseinfoTable.getModel());
        fetchcurrentstockDataFromDatabase((DefaultTableModel) currentstockTable.getModel());
        fetchcustomersDataFromDatabase((DefaultTableModel) customersTable.getModel());
    }
    
    private void fetchpurchaseinfoDataFromDatabase(DefaultTableModel model) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "SELECT * FROM purchaseinfo";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getString("purchaseid"),
                            resultSet.getString("productcode"),
                            resultSet.getString("date"),
                            resultSet.getInt("quantity"),
                            resultSet.getString("totalcost")
                    };
                    model.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void fetchcurrentstockDataFromDatabase(DefaultTableModel model) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "SELECT * FROM currentstock";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getString("productname"),
                            resultSet.getInt("quantity"),
                            resultSet.getString("pid")
                    };
                    model.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void fetchcustomersDataFromDatabase(DefaultTableModel model) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "SELECT * FROM customers";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getString("customercode"),
                            resultSet.getString("fullname"),
                            resultSet.getString("address"),
                            resultSet.getString("contactnumber")
                    };
                    model.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    private void initializeUI() {
        setTitle("Inventory Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 380);
        setLocationRelativeTo(null);

        mainTabbedPane = new JTabbedPane(JTabbedPane.LEFT);
        mainTabbedPane.setForeground(new Color(0, 0, 204));
        mainTabbedPane.setBackground(new Color(255, 204, 0));
        mainTabbedPane.setBorder(new LineBorder(new Color(0, 0, 204), 3));

        JPanel mainTabPanel = new JPanel();

       
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {

            Vector<String> productColumnNames = new Vector<>();
            productColumnNames.add("Product Name");
            productColumnNames.add("Brand");
            productColumnNames.add("Price");

            Vector<Vector<Object>> productData = new Vector<>();

            // Fetch data from the 'products' table
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM products")) {

                while (resultSet.next()) {
                    Vector<Object> rowData = new Vector<>();
                    rowData.add(resultSet.getObject("productname"));
                    rowData.add(resultSet.getObject("phonebrand"));
                    rowData.add(resultSet.getObject("sellprice"));
                    productData.add(rowData);
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                // Handle the exception appropriately (e.g., show an error message)
            }

            DefaultTableModel productTableModel = new DefaultTableModel(productData, productColumnNames);
            JTable productTable = new JTable(productTableModel);
            JScrollPane productScrollPane = new JScrollPane(productTable);
            productScrollPane.setBounds(10, 10, 300, 200); // Adjust the bounds accordingly


            // Add a mouse listener to the product table
            productTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int selectedRow = productTable.getSelectedRow();
                    String details = productTableModel.getValueAt(selectedRow, 1).toString();
                    JOptionPane.showMessageDialog(Main.this, details, "Product Details", JOptionPane.INFORMATION_MESSAGE);
                }
            });
        
        Object[][] purchaseinfoData = {
        };

        Object[] purchaseinfoColumnNames = {"Sales ID", "Supplier ID", "Product Code", "Date", "Quantity", "Total Cost"};
        
        Object[][] employeesData = {
                {"John Rhey", "123-456-7890", "john.rhey@example.com", "E001"},
                {"Jane TheVirgin", "987-654-3210", "jane.thevirgin@example.com", "E002"},
                {"Bob Marley", "555-123-4567", "bob.marley@example.com", "E003"}
        };

        Object[] employeesColumnNames = {"Name", "Phone", "Email", "Employee ID"};

        Object[][] currentstocktableData = {
        };

        Object[] columnNames = {"Product Name", "Quantity", "Product ID"};

        DefaultTableModel currentstockTableModel = new DefaultTableModel(currentstocktableData, columnNames);

        Object[][] customersData = {
        };
        Object[] customersColumnNames = {"Customer Code", "Full Name", "Address", "Contact Number"};

        DefaultTableModel customersTableModel = new DefaultTableModel(customersData, customersColumnNames);

        mainTabbedPane.addTab("Home", mainTabPanel);
        mainTabPanel.setLayout(new BorderLayout(0, 0));
        
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(new Color(255, 204, 0), 5, true));
        panel.setBackground(new Color(0, 0, 204));
        mainTabPanel.add(panel);
        panel.setLayout(null);
        
        JTextArea txtrBsitr = new JTextArea();
        txtrBsitr.setBounds(241, 59, 74, 23);
        txtrBsitr.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 15));
        txtrBsitr.setForeground(new Color(255, 204, 0));
        txtrBsitr.setBackground(new Color(0, 0, 204));
        txtrBsitr.setText("BSIT-2R1");
        panel.add(txtrBsitr);
        
        JTextArea txtrInventory = new JTextArea();
        txtrInventory.setText("INVENTORY");
        txtrInventory.setForeground(Color.WHITE);
        txtrInventory.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrInventory.setBackground(new Color(0, 0, 204));
        txtrInventory.setBounds(165, 93, 226, 46);
        panel.add(txtrInventory);
        
        JTextArea txtrManagen = new JTextArea();
        txtrManagen.setText("MANAGEMENT");
        txtrManagen.setForeground(Color.WHITE);
        txtrManagen.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrManagen.setBackground(new Color(0, 0, 204));
        txtrManagen.setBounds(138, 145, 280, 46);
        panel.add(txtrManagen);
        
        JTextArea txtrSystem = new JTextArea();
        txtrSystem.setText("SYSTEM");
        txtrSystem.setForeground(Color.WHITE);
        txtrSystem.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrSystem.setBackground(new Color(0, 0, 204));
        txtrSystem.setBounds(201, 202, 154, 46);
        panel.add(txtrSystem);

        getContentPane().add(mainTabbedPane, BorderLayout.CENTER);
                
                        // Create the "Product" panel on the left
                        JPanel productPanel = new JPanel();
                        mainTabbedPane.addTab("Product", null, productPanel, null);
                        productPanel.setBackground(new Color(0, 0, 153));
                        productPanel.setForeground(new Color(0, 0, 139));
                        productPanel.setLayout(null);
                        
                                // Product Code Input Box with Label
                                JLabel productCodeLabel = new JLabel("Product Code:");
                                productCodeLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                productCodeLabel.setForeground(new Color(255, 204, 0));
                                productCodeLabel.setBounds(320, 20, 100, 20);
                                JTextField productCodeTextField = new JTextField();
                                productCodeTextField.setBounds(430, 20, 80, 20);
                                
                                        // Product Name Input Box with Label
                                        JLabel productNameLabel = new JLabel("Product Name:");
                                        productNameLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                        productNameLabel.setForeground(new Color(255, 204, 0));
                                        productNameLabel.setBounds(320, 50, 100, 20);
                                        JTextField productNameTextField = new JTextField();
                                        productNameTextField.setBounds(430, 50, 80, 20);
                                        
                                                // Cost Price Input Box with Label
                                                JLabel costPriceLabel = new JLabel("Cost Price:");
                                                costPriceLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                costPriceLabel.setForeground(new Color(255, 204, 0));
                                                costPriceLabel.setBounds(320, 80, 100, 20);
                                                JTextField costPriceTextField = new JTextField();
                                                costPriceTextField.setBounds(430, 80, 80, 20);
                                                
                                                        // Sell Price Input Box with Label
                                                        JLabel sellPriceLabel = new JLabel("Sell Price:");
                                                        sellPriceLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                        sellPriceLabel.setForeground(new Color(255, 204, 0));
                                                        sellPriceLabel.setBounds(320, 111, 100, 20);
                                                        JTextField sellPriceTextField = new JTextField();
                                                        sellPriceTextField.setBounds(430, 111, 80, 20);
                                                        
                                                                // Brand Input Box with Label
                                                                JLabel brandLabel = new JLabel("Brand:");
                                                                brandLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                                brandLabel.setForeground(new Color(255, 204, 0));
                                                                brandLabel.setBounds(320, 140, 100, 20);
                                                                JTextField brandTextField = new JTextField();
                                                                brandTextField.setBounds(430, 140, 80, 20);
                                                                
                                                                // Brand Input Box with Label
                                                                JLabel quantityLabel = new JLabel("Quantity:");
                                                                quantityLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                                quantityLabel.setForeground(new Color(255, 204, 0));
                                                                quantityLabel.setBounds(320, 140, 100, 20);
                                                                JTextField quantityTextField = new JTextField();
                                                                quantityTextField.setBounds(430, 140, 80, 20);
                                                                
                                                                        // Buttons
                                                                        JButton addButton = new JButton("Add");
                                                                        addButton.setFont(new Font("Montserrat SemiBold", Font.PLAIN, 11));
                                                                        addButton.setBounds(372, 171, 60, 25);
                                                                        
                                                                                JButton removeButton = new JButton("Remove");
                                                                                removeButton.setFont(new Font("Montserrat SemiBold", Font.PLAIN, 11));
                                                                                removeButton.setBounds(440, 170, 100, 25);
                                                                                
                                                                                        productPanel.add(productCodeLabel);
                                                                                        productPanel.add(productCodeTextField);
                                                                                        productPanel.add(productNameLabel);
                                                                                        productPanel.add(productNameTextField);
                                                                                        productPanel.add(costPriceLabel);
                                                                                        productPanel.add(costPriceTextField);
                                                                                        productPanel.add(sellPriceLabel);
                                                                                        productPanel.add(sellPriceTextField);
                                                                                        productPanel.add(brandLabel);
                                                                                        productPanel.add(brandTextField);
                                                                                        productPanel.add(quantityLabel);
                                                                                        productPanel.add(quantityTextField);
                                                                                        productPanel.add(addButton);
                                                                                        productPanel.add(removeButton);
                                                                                        
                                                                                                // Add a titled border to the "Product" panel
                                                                                                productPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 224, 0), 2), "Product", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(255, 255, 255)));
                                                                                                
                                                                                                int scrollPaneX = 15;
                                                                                                int scrollPaneY = 15;
                                                                                                int scrollPaneWidth = 300;  // Adjust the width accordingly
                                                                                                int scrollPaneHeight = 300;  // Adjust the height accordingly
                                                                                                productScrollPane.setBounds(scrollPaneX, scrollPaneY, scrollPaneWidth, scrollPaneHeight);
                                                                                                productPanel.add(productScrollPane);
                                                                                                
                                                                                                        // Text area to display action log
                                                                                                        JTextArea actionLogTextAreaProduct = new JTextArea(5, 20);
                                                                                                        actionLogTextAreaProduct.setBackground(Color.LIGHT_GRAY);
                                                                                                        actionLogTextAreaProduct.setBounds(36, 18, 240, 277);
                                                                                                        productPanel.add(actionLogTextAreaProduct);
                                                                                                        actionLogTextAreaProduct.setEditable(false);
                                                                                                        
                                                                                                        
                                                                                                                addButton.addActionListener(new ActionListener() {
                                                                                                                    @Override
                                                                                                                    public void actionPerformed(ActionEvent e) {
                                                                                                                        // Perform the add operation and update the results in the JTextArea
                                                                                                                        String productCode = productCodeTextField.getText();
                                                                                                                        String productName = productNameTextField.getText();
                                                                                                                        String costPrice = costPriceTextField.getText();
                                                                                                                        String sellPrice = sellPriceTextField.getText();
                                                                                                                        String brand = brandTextField.getText();
                                                                                                        
                                                                                                                        // Insert into SQL database (replace with your actual database connection details)
                                                                                                                        insertProductToDatabase(productCode, productName, costPrice, sellPrice, brand);
                                                                                                        
                                                                                                                        updateActionLog(productTableModel, "Product added to database:\n" +
                                                                                                                                "Product Code: " + productCode +
                                                                                                                                "\nProduct Name: " + productName +
                                                                                                                                "\nCost Price: " + costPrice +
                                                                                                                                "\nSell Price: " + sellPrice +
                                                                                                                                "\nBrand: " + brand);
                                                                                                                    }
                                                                                                                });
                                                                                                                
                                                                                                                        removeButton.addActionListener(new ActionListener() {
                                                                                                                            @Override
                                                                                                                            public void actionPerformed(ActionEvent e) {
                                                                                                                                // Perform the remove operation and update the results in the JTextArea
                                                                                                                                String productCode = productCodeTextField.getText();
                                                                                                                
                                                                                                                                // Remove from SQL database (replace with your actual database connection details)
                                                                                                                                removeProductFromDatabase(productCode);
                                                                                                                
                                                                                                                                updateActionLog(productTableModel, "Product removed from database:\n" +
                                                                                                                                        "Product Code: " + productCode);
                                                                                                                            }
                                                                                                                        });
                        
                             // Create the "Sales" panel with a JTable
                                JPanel purchaseinfoPanel = new JPanel();
                                purchaseinfoPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Sales", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
                                mainTabbedPane.addTab("Sales", null, purchaseinfoPanel, null);
                                purchaseinfoPanel.setBackground(new Color(0, 0, 153));
                                purchaseinfoPanel.setLayout(new BorderLayout(0, 0));
                                
                                        purchaseinfoTable = new JTable(new DefaultTableModel(purchaseinfoData, purchaseinfoColumnNames));
                                        purchaseinfoTable.setBackground(new Color(153, 255, 255));
                                        JScrollPane scrollPane = new JScrollPane(purchaseinfoTable);
                                        scrollPane.setBackground(new Color(153, 255, 255));
                                        purchaseinfoPanel.add(scrollPane);
                
                        // Create the "View Stocks" panel with a JTable and search functionality
                        JPanel viewcurrentstockPanel = new JPanel();
                        mainTabbedPane.addTab("Current Stocks", null, viewcurrentstockPanel, null);
                        viewcurrentstockPanel.setBackground(new Color(0, 0, 153));
                        viewcurrentstockPanel.setLayout(new BorderLayout());
                        
                                // Search Text Box with Button
                        JPanel searchPanel = new JPanel();
                        searchPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
                        searchPanel.setBackground(new Color(255, 204, 0));
                        JTextField searchTextField = new JTextField(10);
                        JButton searchButton = new JButton("Search");
                        JButton updateButton = new JButton("Update"); // Add the Update button

                        searchPanel.add(searchTextField);
                        searchPanel.add(searchButton);
                        searchPanel.add(updateButton); // Add the Update button

                        
                        // Add ActionListener to the Update button
                        updateButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
								// Perform the update operation and refresh the results in the JTable
                                refreshcurrentstockTable(currentstockTableModel);
                            }
                        });

                        viewcurrentstockPanel.add(searchPanel, BorderLayout.NORTH);
                                        
                                                // Add a titled border to the "View Stocks" panel
                        			viewcurrentstockPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "View Stocks", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(255, 204, 0)));
                                                
                                                        viewcurrentstockPanel.add(searchPanel, BorderLayout.NORTH);
                                                        currentstockTable = new JTable(currentstockTableModel);
                                                        currentstockTable.setBackground(new Color(102, 255, 255));
                                                        viewcurrentstockPanel.add(new JScrollPane(currentstockTable), BorderLayout.CENTER);
                                                        
                                                                searchButton.addActionListener(new ActionListener() {
                                                                    @Override
                                                                    public void actionPerformed(ActionEvent e) {
                                                                        // Perform the search operation and update the results in the JTable
                                                                        String searchTerm = searchTextField.getText();
                                                                        searchProductIDAndMoveToTop(currentstockTableModel, searchTerm);
                                                                    }
                                                                });
                
                     // Create the "Customers" panel with a JTable
                        JPanel customersPanel = new JPanel();
                        customersPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Customers", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 204, 0)));
                        mainTabbedPane.addTab("Customers", null, customersPanel, null);
                        customersPanel.setBackground(new Color(0, 0, 204));
                        customersPanel.setLayout(new BorderLayout(0, 0));
                        customersTable = new JTable(customersTableModel);
                        customersTable.setBackground(new Color(102, 255, 255));
                        JScrollPane scrollPane_1 = new JScrollPane(customersTable);
                        customersPanel.add(scrollPane_1);
        
                // Create the "Employees" panel with a JTable
                JPanel employeesPanel = new JPanel();
                employeesPanel.setBackground(new Color(0, 0, 153));
                employeesPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Employees", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 204, 0)));
                mainTabbedPane.addTab("Employees", null, employeesPanel, null);
                        employeesPanel.setLayout(new BorderLayout(0, 0));
                
                        JTable employeesTable = new JTable(new DefaultTableModel(employeesData, employeesColumnNames));
                        JScrollPane scrollPane_2 = new JScrollPane(employeesTable);
                        employeesPanel.add(scrollPane_2);} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
    }

    private void updateActionLog(DefaultTableModel actionLogTableModel, String log) {
        Vector<String> row = new Vector<>();
        row.add(log.split("\n")[0]);  // Action
        row.add(log.substring(log.indexOf("\n") + 1));  // Details
        actionLogTableModel.addRow(row);
    }
    
    private void refreshcurrentstockTable(DefaultTableModel currentstockTableModel) {
       
        currentstockTableModel.setRowCount(0);

        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String query = "SELECT * FROM currentstock";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                // Populate the table model with retrieved data
                while (resultSet.next()) {
                    // Assuming your_stock_table has columns "column1", "column2", etc.
                    Object[] rowData = {
                    		resultSet.getObject("productname"),
                    		resultSet.getObject("quantity"),
                            resultSet.getObject("pid"),
                            // Add more columns as needed
                    };
                    currentstockTableModel.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            // Handle the exception appropriately (e.g., show an error message)
        }
    }

    private void insertProductToDatabase(String productCode, String productName, String costPrice, String sellPrice, String brand) {
      
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "INSERT INTO products (productcode, productname, costprice, sellprice, phonebrand) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, productCode);
                preparedStatement.setString(2, productName);
                preparedStatement.setString(3, costPrice);
                preparedStatement.setString(4, sellPrice);
                preparedStatement.setString(5, brand);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    private void removeProductFromDatabase(String productCode) {

        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "DELETE FROM currentstock WHERE productcode = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, productCode);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void searchProductIDAndMoveToTop(DefaultTableModel model, String searchTerm) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String query = "SELECT * FROM currentstock WHERE productcode = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, searchTerm);
                
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // Move the row to the top
                        Vector<Object> rowData = new Vector<>();
                        for (int col = 1; col <= model.getColumnCount(); col++) {
                            rowData.add(resultSet.getObject(col));
                        }
                        model.insertRow(0, rowData);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Product ID not found", "Search Result", JOptionPane.INFORMATION_MESSAGE);
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }

	public JTabbedPane getMainTabbedPane() {
		return mainTabbedPane;
	}

	public void setMainTabbedPane(JTabbedPane mainTabbedPane) {
		this.mainTabbedPane = mainTabbedPane;
	}

	public JTabbedPane getEmployeesTabbedPane() {
		return employeesTabbedPane;
	}

	public void setEmployeesTabbedPane(JTabbedPane employeesTabbedPane) {
		this.employeesTabbedPane = employeesTabbedPane;
	}

	public JTable getPurchaseinfoTable() {
		return purchaseinfoTable;
	}

	public void setPurchaseinfoTable(JTable purchaseinfoTable) {
		this.purchaseinfoTable = purchaseinfoTable;
	}

	public JTable getCurrentstockTable() {
		return currentstockTable;
	}

	public void setCurrentstockTable(JTable currentstockTable) {
		this.currentstockTable = currentstockTable;
	}

	public JTable getCustomersTable() {
		return customersTable;
	}

	public void setCustomersTable(JTable customersTable) {
		this.customersTable = customersTable;
	}
}