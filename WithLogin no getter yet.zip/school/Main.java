import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main extends JFrame {

    private JTabbedPane mainTabbedPane;
    private JTabbedPane employeesTabbedPane;

    public Main() {
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Inventory Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 380);
        setLocationRelativeTo(null);

        mainTabbedPane = new JTabbedPane(JTabbedPane.LEFT);
        mainTabbedPane.setForeground(new Color(0, 0, 204));
        mainTabbedPane.setBackground(new Color(255, 204, 0));
        mainTabbedPane.setBorder(new LineBorder(new Color(0, 0, 204), 3));

        JPanel mainTabPanel = new JPanel();

        Vector<String> actionLogColumnNames = new Vector<>();
        actionLogColumnNames.add("Action");
        actionLogColumnNames.add("Details");

        Vector<Vector<String>> actionLogData = new Vector<>();
        DefaultTableModel actionLogTableModel = new DefaultTableModel(actionLogData, actionLogColumnNames);

        // Dummy data for the action log table (replace this with SQL data)
        Object[][] actionLogDummyData = {
                {"Add", "Product added to database:\nProduct Code: P001\nProduct Name: Product 1\nCost Price: 10\nSell Price: 20\nBrand: Brand A"},
                {"Remove", "Product removed from database:\nProduct Code: P002"}
        };

        for (Object[] rowData : actionLogDummyData) {
            actionLogTableModel.addRow(rowData);
        }

        JTable actionLogTable = new JTable(actionLogTableModel);
        JScrollPane actionLogScrollPane = new JScrollPane(actionLogTable);
        actionLogScrollPane.setBounds(10, 10, 300, 200); // Adjust the bounds accordingly


        // Add a mouse listener to the action log table for future database connection
        actionLogTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Handle mouse click on action log table (e.g., display details or connect to the database)
                int selectedRow = actionLogTable.getSelectedRow();
                String details = actionLogTableModel.getValueAt(selectedRow, 1).toString();
                JOptionPane.showMessageDialog(Main.this, details, "Action Log Details", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        

        // Dummy data for the table (replace this with SQL data)
        Object[][] salesData = {
                {"S001", "Supplier A", "Product A", "2024-01-01", 1, "$50.00"},
                {"S002", "Supplier B", "Product B", "2024-01-02", 2, "$80.00"},
                {"S003", "Supplier C", "Product C", "2024-01-03", 3, "$100.00"}
        };

        Object[] salesColumnNames = {"Sales ID", "Supplier ID", "Product Code", "Date", "Quantity", "Total Cost"};

        // Dummy data for the table (replace this with SQL data)
        Object[][] employeesData = {
                {"John Rhey", "123-456-7890", "john.rhey@example.com", "E001"},
                {"Jane TheVirgin", "987-654-3210", "jane.thevirgin@example.com", "E002"},
                {"Bob Marley", "555-123-4567", "bob.marley@example.com", "E003"}
        };

        Object[] employeesColumnNames = {"Name", "Phone", "Email", "Employee ID"};

        // Dummy data for the table (replace this with SQL data)
        Object[][] tableData = {
                {"Product 1", 10, "P001"},
                {"Product 2", 20, "P002"},
                {"Product 3", 30, "P003"}
        };

        Object[] columnNames = {"Product Name", "Quantity", "Product ID"};

        DefaultTableModel stocksTableModel = new DefaultTableModel(tableData, columnNames);

        // Dummy data for the table (replace this with SQL data)
        Object[][] customersData = {
                {"C001", "Customer 1", "Address 1", "123-456-7890"},
                {"C002", "Customer 2", "Address 2", "987-654-3210"},
                {"C003", "Customer 3", "Address 3", "555-123-4567"}
        };

        Object[] customersColumnNames = {"Customer Code", "Full Name", "Address", "Contact Number"};

        DefaultTableModel customersTableModel = new DefaultTableModel(customersData, customersColumnNames);

        mainTabbedPane.addTab("Home", mainTabPanel);
        mainTabPanel.setLayout(new BorderLayout(0, 0));
        
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(new Color(255, 204, 0), 5, true));
        panel.setBackground(new Color(0, 0, 204));
        mainTabPanel.add(panel);
        panel.setLayout(null);
        
        JTextArea txtrBsitr = new JTextArea();
        txtrBsitr.setBounds(241, 59, 74, 23);
        txtrBsitr.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 15));
        txtrBsitr.setForeground(new Color(255, 204, 0));
        txtrBsitr.setBackground(new Color(0, 0, 204));
        txtrBsitr.setText("BSIT-2R1");
        panel.add(txtrBsitr);
        
        JTextArea txtrInventory = new JTextArea();
        txtrInventory.setText("INVENTORY");
        txtrInventory.setForeground(Color.WHITE);
        txtrInventory.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrInventory.setBackground(new Color(0, 0, 204));
        txtrInventory.setBounds(165, 93, 226, 46);
        panel.add(txtrInventory);
        
        JTextArea txtrManagen = new JTextArea();
        txtrManagen.setText("MANAGEMENT");
        txtrManagen.setForeground(Color.WHITE);
        txtrManagen.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrManagen.setBackground(new Color(0, 0, 204));
        txtrManagen.setBounds(138, 145, 280, 46);
        panel.add(txtrManagen);
        
        JTextArea txtrSystem = new JTextArea();
        txtrSystem.setText("SYSTEM");
        txtrSystem.setForeground(Color.WHITE);
        txtrSystem.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrSystem.setBackground(new Color(0, 0, 204));
        txtrSystem.setBounds(201, 202, 154, 46);
        panel.add(txtrSystem);

        getContentPane().add(mainTabbedPane, BorderLayout.CENTER);
                
                        // Create the "Product" panel on the left
                        JPanel productPanel = new JPanel();
                        mainTabbedPane.addTab("Product", null, productPanel, null);
                        productPanel.setBackground(new Color(0, 0, 153));
                        productPanel.setForeground(new Color(0, 0, 139));
                        productPanel.setLayout(null);
                        
                                // Product Code Input Box with Label
                                JLabel productCodeLabel = new JLabel("Product Code:");
                                productCodeLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                productCodeLabel.setForeground(new Color(255, 204, 0));
                                productCodeLabel.setBounds(320, 20, 100, 20);
                                JTextField productCodeTextField = new JTextField();
                                productCodeTextField.setBounds(430, 20, 80, 20);
                                
                                        // Product Name Input Box with Label
                                        JLabel productNameLabel = new JLabel("Product Name:");
                                        productNameLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                        productNameLabel.setForeground(new Color(255, 204, 0));
                                        productNameLabel.setBounds(320, 50, 100, 20);
                                        JTextField productNameTextField = new JTextField();
                                        productNameTextField.setBounds(430, 50, 80, 20);
                                        
                                                // Cost Price Input Box with Label
                                                JLabel costPriceLabel = new JLabel("Cost Price:");
                                                costPriceLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                costPriceLabel.setForeground(new Color(255, 204, 0));
                                                costPriceLabel.setBounds(320, 80, 100, 20);
                                                JTextField costPriceTextField = new JTextField();
                                                costPriceTextField.setBounds(430, 80, 80, 20);
                                                
                                                        // Sell Price Input Box with Label
                                                        JLabel sellPriceLabel = new JLabel("Sell Price:");
                                                        sellPriceLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                        sellPriceLabel.setForeground(new Color(255, 204, 0));
                                                        sellPriceLabel.setBounds(320, 111, 100, 20);
                                                        JTextField sellPriceTextField = new JTextField();
                                                        sellPriceTextField.setBounds(430, 111, 80, 20);
                                                        
                                                                // Brand Input Box with Label
                                                                JLabel brandLabel = new JLabel("Brand:");
                                                                brandLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                                brandLabel.setForeground(new Color(255, 204, 0));
                                                                brandLabel.setBounds(320, 140, 100, 20);
                                                                JTextField brandTextField = new JTextField();
                                                                brandTextField.setBounds(430, 140, 80, 20);
                                                                
                                                                        // Buttons
                                                                        JButton addButton = new JButton("Add");
                                                                        addButton.setFont(new Font("Montserrat SemiBold", Font.PLAIN, 11));
                                                                        addButton.setBounds(372, 171, 60, 25);
                                                                        
                                                                                JButton removeButton = new JButton("Remove");
                                                                                removeButton.setFont(new Font("Montserrat SemiBold", Font.PLAIN, 11));
                                                                                removeButton.setBounds(440, 170, 100, 25);
                                                                                
                                                                                        productPanel.add(productCodeLabel);
                                                                                        productPanel.add(productCodeTextField);
                                                                                        productPanel.add(productNameLabel);
                                                                                        productPanel.add(productNameTextField);
                                                                                        productPanel.add(costPriceLabel);
                                                                                        productPanel.add(costPriceTextField);
                                                                                        productPanel.add(sellPriceLabel);
                                                                                        productPanel.add(sellPriceTextField);
                                                                                        productPanel.add(brandLabel);
                                                                                        productPanel.add(brandTextField);
                                                                                        productPanel.add(addButton);
                                                                                        productPanel.add(removeButton);
                                                                                        
                                                                                                // Add a titled border to the "Product" panel
                                                                                                productPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 2), "Product", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(255, 255, 255)));
                                                                                                
                                                                                                        // Text area to display action log
                                                                                                        JTextArea actionLogTextAreaProduct = new JTextArea(5, 20);
                                                                                                        actionLogTextAreaProduct.setBackground(Color.LIGHT_GRAY);
                                                                                                        actionLogTextAreaProduct.setBounds(36, 18, 240, 277);
                                                                                                        productPanel.add(actionLogTextAreaProduct);
                                                                                                        actionLogTextAreaProduct.setEditable(false);
                                                                                                        
                                                                                                                addButton.addActionListener(new ActionListener() {
                                                                                                                    @Override
                                                                                                                    public void actionPerformed(ActionEvent e) {
                                                                                                                        // Perform the add operation and update the results in the JTextArea
                                                                                                                        String productCode = productCodeTextField.getText();
                                                                                                                        String productName = productNameTextField.getText();
                                                                                                                        String costPrice = costPriceTextField.getText();
                                                                                                                        String sellPrice = sellPriceTextField.getText();
                                                                                                                        String brand = brandTextField.getText();
                                                                                                        
                                                                                                                        // Insert into SQL database (replace with your actual database connection details)
                                                                                                                        insertProductToDatabase(productCode, productName, costPrice, sellPrice, brand);
                                                                                                        
                                                                                                                        updateActionLog(actionLogTableModel, "Product added to database:\n" +
                                                                                                                                "Product Code: " + productCode +
                                                                                                                                "\nProduct Name: " + productName +
                                                                                                                                "\nCost Price: " + costPrice +
                                                                                                                                "\nSell Price: " + sellPrice +
                                                                                                                                "\nBrand: " + brand);
                                                                                                                    }
                                                                                                                });
                                                                                                                
                                                                                                                        removeButton.addActionListener(new ActionListener() {
                                                                                                                            @Override
                                                                                                                            public void actionPerformed(ActionEvent e) {
                                                                                                                                // Perform the remove operation and update the results in the JTextArea
                                                                                                                                String productCode = productCodeTextField.getText();
                                                                                                                
                                                                                                                                // Remove from SQL database (replace with your actual database connection details)
                                                                                                                                removeProductFromDatabase(productCode);
                                                                                                                
                                                                                                                                updateActionLog(actionLogTableModel, "Product removed from database:\n" +
                                                                                                                                        "Product Code: " + productCode);
                                                                                                                            }
                                                                                                                        });
                        
                             // Create the "Sales" panel with a JTable
                                JPanel salesPanel = new JPanel();
                                salesPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Sales", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
                                mainTabbedPane.addTab("Sales", null, salesPanel, null);
                                salesPanel.setBackground(new Color(0, 0, 153));
                                        salesPanel.setLayout(new BorderLayout(0, 0));
                                
                                        JTable salesTable = new JTable(new DefaultTableModel(salesData, salesColumnNames));
                                        salesTable.setBackground(new Color(153, 255, 255));
                                        JScrollPane scrollPane = new JScrollPane(salesTable);
                                        scrollPane.setBackground(new Color(153, 255, 255));
                                        salesPanel.add(scrollPane);
                
                        // Create the "View Stocks" panel with a JTable and search functionality
                        JPanel viewStocksPanel = new JPanel();
                        mainTabbedPane.addTab("Current Stocks", null, viewStocksPanel, null);
                        viewStocksPanel.setBackground(new Color(0, 0, 153));
                        viewStocksPanel.setLayout(new BorderLayout());
                        
                                // Search Text Box with Button
                        JPanel searchPanel = new JPanel();
                        searchPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
                        searchPanel.setBackground(new Color(255, 204, 0));
                        JTextField searchTextField = new JTextField(10);
                        JButton searchButton = new JButton("Search");
                        JButton updateButton = new JButton("Update"); // Add the Update button

                        searchPanel.add(searchTextField);
                        searchPanel.add(searchButton);
                        searchPanel.add(updateButton); // Add the Update button

                        // Add ActionListener to the Update button
                        updateButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                // Perform the update operation and refresh the results in the JTable
                                refreshStocksTable(stocksTableModel);
                            }
                        });

                        viewStocksPanel.add(searchPanel, BorderLayout.NORTH);
                                        
                                                // Add a titled border to the "View Stocks" panel
                                                viewStocksPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "View Stocks", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(255, 204, 0)));
                                                
                                                        viewStocksPanel.add(searchPanel, BorderLayout.NORTH);
                                                        JTable stocksTable = new JTable(stocksTableModel);
                                                        stocksTable.setBackground(new Color(102, 255, 255));
                                                        viewStocksPanel.add(new JScrollPane(stocksTable), BorderLayout.CENTER);
                                                        
                                                                searchButton.addActionListener(new ActionListener() {
                                                                    @Override
                                                                    public void actionPerformed(ActionEvent e) {
                                                                        // Perform the search operation and update the results in the JTable
                                                                        String searchTerm = searchTextField.getText();
                                                                        searchProductIDAndMoveToTop(stocksTableModel, searchTerm);
                                                                    }
                                                                });
                
                     // Create the "Customers" panel with a JTable
                        JPanel customersPanel = new JPanel();
                        customersPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Customers", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 204, 0)));
                        mainTabbedPane.addTab("Customers", null, customersPanel, null);
                        customersPanel.setBackground(new Color(0, 0, 204));
                        customersPanel.setLayout(new BorderLayout(0, 0));
                        JTable customersTable = new JTable(customersTableModel);
                        customersTable.setBackground(new Color(102, 255, 255));
                        JScrollPane scrollPane_1 = new JScrollPane(customersTable);
                        customersPanel.add(scrollPane_1);
        
                // Create the "Employees" panel with a JTable
                JPanel employeesPanel = new JPanel();
                employeesPanel.setBackground(new Color(0, 0, 153));
                employeesPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Employees", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 204, 0)));
                mainTabbedPane.addTab("Employees", null, employeesPanel, null);
                        employeesPanel.setLayout(new BorderLayout(0, 0));
                
                        JTable employeesTable = new JTable(new DefaultTableModel(employeesData, employeesColumnNames));
                        JScrollPane scrollPane_2 = new JScrollPane(employeesTable);
                        employeesPanel.add(scrollPane_2);
    }

    private void updateActionLog(DefaultTableModel actionLogTableModel, String log) {
        Vector<String> row = new Vector<>();
        row.add(log.split("\n")[0]);  // Action
        row.add(log.substring(log.indexOf("\n") + 1));  // Details
        actionLogTableModel.addRow(row);
    }
    
    private void refreshStocksTable(DefaultTableModel stocksTableModel) {
        // TODO: Implement logic to refresh the stocks table data
        // Fetch updated data from your data source and update the table model

        // For demonstration purposes, I'm clearing the existing data and adding dummy data.
        stocksTableModel.setRowCount(0);

        // Dummy data (replace this with actual data retrieval logic)
        Object[][] updatedStocksData = {
                {"Product X", 15, "P004"},
                {"Product Y", 25, "P005"},
                {"Product Z", 35, "P006"}
        };

        for (Object[] rowData : updatedStocksData) {
            stocksTableModel.addRow(rowData);
        }
    }

    private void insertProductToDatabase(String productCode, String productName, String costPrice, String sellPrice, String brand) {
      
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "username", "password")) {
            String sql = "INSERT INTO products (product_code, product_name, cost_price, sell_price, brand) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, productCode);
                preparedStatement.setString(2, productName);
                preparedStatement.setString(3, costPrice);
                preparedStatement.setString(4, sellPrice);
                preparedStatement.setString(5, brand);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    private void removeProductFromDatabase(String productCode) {
        // TODO: Implement database removal logic
        // Example code (replace with your actual database connection details)
        /*
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "username", "password")) {
            String sql = "DELETE FROM products WHERE product_code = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, productCode);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        */
    }

    private void searchProductIDAndMoveToTop(DefaultTableModel model, String searchTerm) {
        for (int row = 0; row < model.getRowCount(); row++) {
            Object value = model.getValueAt(row, 2); // Assuming Product ID is in the third column
            if (value != null && value.toString().equals(searchTerm)) {
                // Move the row to the top
                Vector<Object> rowData = new Vector<>();
                for (int col = 0; col < model.getColumnCount(); col++) {
                    rowData.add(model.getValueAt(row, col));
                }
                model.removeRow(row);
                model.insertRow(0, rowData);
                return; // Assuming there is only one occurrence of the Product ID
            }
        }
        JOptionPane.showMessageDialog(this, "Product ID not found", "Search Result", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}