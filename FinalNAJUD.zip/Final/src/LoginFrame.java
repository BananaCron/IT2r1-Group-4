import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.border.LineBorder;

public class LoginFrame extends JFrame {

	private JTextField usernameField;
	private JPasswordField passwordField;
	private int loginAttempts = 0;

	private static final String DB_URL = "jdbc:postgresql://localhost:5432/Inventory";
	private static final String DB_USER = "postgres";
	private static final String DB_PASSWORD = "143puddiepie";

	public LoginFrame() {
		initializeUI();
	}

	private void initializeUI() {
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(420, 243);
		setLocationRelativeTo(null);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(255, 255, 0), 3));
		panel.setBackground(new Color(0, 0, 204));

		JLabel usernameLabel = new JLabel("  Username:");
		usernameLabel.setForeground(new Color(255, 255, 224));
		usernameLabel.setBackground(Color.BLACK);
		usernameLabel.setBounds(88, 38, 226, 30);
		usernameLabel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true)); // Add border to usernameLabel
		usernameField = new JTextField();
		usernameField.setBackground(new Color(192, 192, 192));
		usernameField.setForeground(new Color(0, 0, 128));
		usernameField.setBounds(164, 38, 150, 30);
		usernameField.setBorder(new LineBorder(new Color(255, 255, 255), 3, true)); // Add border to usernameField

		JLabel passwordLabel = new JLabel("  Password:");
		passwordLabel.setBackground(new Color(255, 255, 255));
		passwordLabel.setForeground(new Color(255, 255, 224));
		passwordLabel.setBounds(88, 87, 226, 30);
		passwordLabel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true)); // Add border to passwordLabel
		passwordField = new JPasswordField();
		passwordField.setForeground(new Color(0, 0, 128));
		passwordField.setBackground(new Color(192, 192, 192));
		passwordField.setBounds(164, 87, 150, 30);
		passwordField.setBorder(new LineBorder(new Color(255, 255, 255), 3, true)); // Add border to passwordField

		JButton loginButton = new JButton("Login");
		loginButton.setForeground(new Color(0, 0, 139));
		loginButton.setBackground(new Color(255, 255, 0));
		loginButton.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
		loginButton.setBounds(130, 139, 143, 42);
		loginButton.setBorder(new LineBorder(new Color(255, 215, 0), 3, true)); // Add border to loginButton
		loginButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				performLogin();
			}
		});
		panel.setLayout(null);

		panel.add(usernameLabel);
		panel.add(usernameField);
		panel.add(passwordLabel);
		panel.add(passwordField);
		panel.add(loginButton);

		getContentPane().add(panel, BorderLayout.CENTER);
	}

	private void performLogin() {
		String username = usernameField.getText();
		char[] password = passwordField.getPassword();
		String enteredPassword = new String(password);

		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory",
				"postgres", "143puddiepie")) {
			String query = "SELECT * FROM users WHERE username = ? AND password = ?";
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setString(1, username);
				preparedStatement.setString(2, enteredPassword);

				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					if (resultSet.next()) {
						showStyledPopup("Login successful!", "Success", "Welcome to the Main Program!");
						new Main().setVisible(true);
						this.dispose();
					} else {
						handleFailedLogin();
					}
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			showStyledPopup("Database error. Please try again later.", "Error", "Program will now exit.");
			System.exit(0);
		}
	}

	private void handleFailedLogin() {
		loginAttempts++;
		if (loginAttempts >= 3) {
			showStyledPopup("Too many login attempts. Please try again later.", "Error", "Program will now exit.");
			System.exit(0);
		} else {
			showStyledPopup("Invalid credentials. Please try again.", "Error", "Check your username and password.");
		}
		usernameField.setText("");
		passwordField.setText("");
	}

	private void showStyledPopup(String message, String title, String additionalInfo) {
		JTextPane textPane = new JTextPane();
		textPane.setEditable(false);
		textPane.setBackground(new Color(240, 240, 240));
		textPane.setContentType("text/html");
		textPane.setText("<html><p style='font-family: Arial; font-size: 12pt;'>" + message + "</p>"
				+ "<p style='font-family: Arial; font-size: 10pt; color: #808080;'>" + additionalInfo + "</p></html>");

		JScrollPane scrollPane = new JScrollPane(textPane);
		scrollPane.setBorder(BorderFactory.createEmptyBorder());

		JOptionPane.showMessageDialog(this, scrollPane, title, JOptionPane.INFORMATION_MESSAGE);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
	}

	public JTextField getUsernameField() {
		return usernameField;
	}

	public void setUsernameField(JTextField usernameField) {
		this.usernameField = usernameField;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}

	public int getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(int loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public static String getDbUrl() {
		return DB_URL;
	}

	public static String getDbUser() {
		return DB_USER;
	}

	public static String getDbPassword() {
		return DB_PASSWORD;
	}
}
