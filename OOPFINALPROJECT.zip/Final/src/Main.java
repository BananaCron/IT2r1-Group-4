import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main extends JFrame {

	private JTabbedPane mainTabbedPane;
	private JTabbedPane employeeTabbedPane;
	private JTable currentstockTable;
	private JTable employeeTable;
    
	public Main() {
		initializeUI();
		fetchInitialDataFromDatabase();
	}

	private void fetchInitialDataFromDatabase() {
		fetchcurrentstockDataFromDatabase((DefaultTableModel) currentstockTable.getModel());
		fetchEmployeesDataFromDatabase((DefaultTableModel) employeeTable.getModel());
	}

	private void fetchcurrentstockDataFromDatabase(DefaultTableModel model) {
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory",
				"postgres", "143puddiepie")) {
			String sql = "SELECT * FROM currentstock";
			try (Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)) {

				while (resultSet.next()) {
					Object[] rowData = { resultSet.getString("productcode"), resultSet.getString("productname"),
							resultSet.getInt("quantity"), resultSet.getString("pid") };
					model.addRow(rowData);
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
	private void fetchEmployeesDataFromDatabase(DefaultTableModel model) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory",
                "postgres", "143puddiepie")) {
            String sql = "SELECT * FROM employee";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getString("name"),
                            resultSet.getString("phone"),
                            resultSet.getString("email"),
                            resultSet.getString("employeeID")
                    };
                    model.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
	
	private void initializeUI() {
		setTitle("Phone Inventory Management System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(700, 380);
		setLocationRelativeTo(null);

		mainTabbedPane = new JTabbedPane(JTabbedPane.LEFT);
		mainTabbedPane.setForeground(new Color(0, 0, 204));
		mainTabbedPane.setBackground(new Color(255, 204, 0));
		mainTabbedPane.setBorder(new LineBorder(new Color(0, 0, 204), 3));

		JPanel mainTabPanel = new JPanel();

		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory",
				"postgres", "143puddiepie")) {

			Vector<String> productColumnNames = new Vector<>();
			productColumnNames.add("Product Name");
			productColumnNames.add("Brand");
			productColumnNames.add("Price");

			Vector<Vector<Object>> productData = new Vector<>();

			// Fetch data from the 'products' table
			try (Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery("SELECT * FROM products")) {

				while (resultSet.next()) {
					Vector<Object> rowData = new Vector<>();
					rowData.add(resultSet.getObject("productname"));
					rowData.add(resultSet.getObject("phonebrand"));
					rowData.add(resultSet.getObject("sellprice"));
					productData.add(rowData);
				}

			} catch (SQLException ex) {
				ex.printStackTrace();
				// Handle the exception appropriately (e.g., show an error message)
			}

			DefaultTableModel productTableModel = new DefaultTableModel(productData, productColumnNames);
			JTable productTable = new JTable(productTableModel);
			JScrollPane productScrollPane = new JScrollPane(productTable);
			productScrollPane.setBounds(10, 10, 300, 200); // Adjust the bounds accordingly

			// Add a mouse listener to the product table
			productTable.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					int selectedRow = productTable.getSelectedRow();
					String details = productTableModel.getValueAt(selectedRow, 1).toString();
					JOptionPane.showMessageDialog(Main.this, details, "Product Details",
							JOptionPane.INFORMATION_MESSAGE);
				}
			});

			Object[][] employeeData = {		
			};

			Object[] employeeColumnNames = { "Name", "Phone", "Email", "Employee ID" };

			Object[][] currentstocktableData = {};

			Object[] columnNames = { "Product Code", "Product Name", "Quantity", "Product ID" };

			DefaultTableModel currentstockTableModel = new DefaultTableModel(currentstocktableData, columnNames);

			mainTabbedPane.addTab("Home", mainTabPanel);
			mainTabPanel.setLayout(new BorderLayout(0, 0));

			JPanel panel = new JPanel();
			panel.setBorder(new LineBorder(new Color(255, 204, 0), 5, true));
			panel.setBackground(new Color(0, 0, 204));
			mainTabPanel.add(panel);
			panel.setLayout(null);

			JTextArea txtrBsitr = new JTextArea();
			txtrBsitr.setBounds(241, 59, 74, 23);
			txtrBsitr.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 15));
			txtrBsitr.setForeground(new Color(255, 204, 0));
			txtrBsitr.setBackground(new Color(0, 0, 204));
			txtrBsitr.setText("BSIT-2R1");
			panel.add(txtrBsitr);

			JTextArea txtrInventory = new JTextArea();
			txtrInventory.setText("INVENTORY");
			txtrInventory.setForeground(Color.WHITE);
			txtrInventory.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
			txtrInventory.setBackground(new Color(0, 0, 204));
			txtrInventory.setBounds(165, 93, 226, 46);
			panel.add(txtrInventory);

			JTextArea txtrManagen = new JTextArea();
			txtrManagen.setText("MANAGEMENT");
			txtrManagen.setForeground(Color.WHITE);
			txtrManagen.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
			txtrManagen.setBackground(new Color(0, 0, 204));
			txtrManagen.setBounds(138, 145, 280, 46);
			panel.add(txtrManagen);

			JTextArea txtrSystem = new JTextArea();
			txtrSystem.setText("SYSTEM");
			txtrSystem.setForeground(Color.WHITE);
			txtrSystem.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
			txtrSystem.setBackground(new Color(0, 0, 204));
			txtrSystem.setBounds(201, 202, 154, 46);
			panel.add(txtrSystem);

			getContentPane().add(mainTabbedPane, BorderLayout.CENTER);

			// Create the "Product" panel on the left
			JPanel productPanel = new JPanel();
			mainTabbedPane.addTab("Product", null, productPanel, null);
			productPanel.setBackground(new Color(0, 0, 153));
			productPanel.setForeground(new Color(0, 0, 139));
			productPanel.setLayout(null);

			// Product Code Input Box with Label
			JLabel productCodeLabel = new JLabel("Product Code:");
			productCodeLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
			productCodeLabel.setForeground(new Color(255, 204, 0));
			productCodeLabel.setBounds(320, 20, 100, 20);
			JTextField productCodeTextField = new JTextField();
			productCodeTextField.setBounds(430, 20, 80, 20);

			// Product Name Input Box with Label
			JLabel productNameLabel = new JLabel("Product Name:");
			productNameLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
			productNameLabel.setForeground(new Color(255, 204, 0));
			productNameLabel.setBounds(320, 50, 100, 20);
			JTextField productNameTextField = new JTextField();
			productNameTextField.setBounds(430, 50, 80, 20);

			// Cost Price Input Box with Label
			JLabel costPriceLabel = new JLabel("Cost Price:");
			costPriceLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
			costPriceLabel.setForeground(new Color(255, 204, 0));
			costPriceLabel.setBounds(320, 80, 100, 20);
			JTextField costPriceTextField = new JTextField();
			costPriceTextField.setBounds(430, 80, 80, 20);

			// Sell Price Input Box with Label
			JLabel sellPriceLabel = new JLabel("Sell Price:");
			sellPriceLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
			sellPriceLabel.setForeground(new Color(255, 204, 0));
			sellPriceLabel.setBounds(320, 111, 100, 20);
			JTextField sellPriceTextField = new JTextField();
			sellPriceTextField.setBounds(430, 111, 80, 20);

			// Brand Input Box with Label
			JLabel brandLabel = new JLabel("Brand:");
			brandLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
			brandLabel.setForeground(new Color(255, 204, 0));
			brandLabel.setBounds(320, 140, 100, 20);
			JTextField brandTextField = new JTextField();
			brandTextField.setBounds(430, 140, 80, 20);

			// Buttons
			JButton addButton = new JButton("Add");
			addButton.setFont(new Font("Montserrat SemiBold", Font.PLAIN, 11));
			addButton.setBounds(372, 200, 60, 25);

			JButton removeButton = new JButton("Remove");
			removeButton.setFont(new Font("Montserrat SemiBold", Font.PLAIN, 11));
			removeButton.setBounds(440, 200, 100, 25);

			productPanel.add(productCodeLabel);
			productPanel.add(productCodeTextField);
			productPanel.add(productNameLabel);
			productPanel.add(productNameTextField);
			productPanel.add(costPriceLabel);
			productPanel.add(costPriceTextField);
			productPanel.add(sellPriceLabel);
			productPanel.add(sellPriceTextField);
			productPanel.add(brandLabel);
			productPanel.add(brandTextField);
			productPanel.add(addButton);
			productPanel.add(removeButton);

			// Add a titled border to the "Product" panel
			productPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 224, 0), 2), "Product",
					TitledBorder.LEFT, TitledBorder.TOP, null, new Color(255, 255, 255)));

			// Text area to display action log
			JTextArea actionLogTextAreaProduct = new JTextArea(5, 20);
			actionLogTextAreaProduct.setBackground(Color.LIGHT_GRAY);
			actionLogTextAreaProduct.setBounds(36, 18, 240, 277);
			productPanel.add(actionLogTextAreaProduct);
			actionLogTextAreaProduct.setEditable(false);

			addButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// Perform the add operation and update the results in the JTextArea
					String productCode = productCodeTextField.getText();
					String productName = productNameTextField.getText();
					String costPrice = costPriceTextField.getText();
					String sellPrice = sellPriceTextField.getText();
					String brand = brandTextField.getText();

					// Insert into SQL database (replace with your actual database connection
					// details)
					insertProductToDatabase(productCode, productName, costPrice, sellPrice, brand);

					// Update the action log JTextArea
					updateActionLog(actionLogTextAreaProduct,
							"Product added to database:\n" + "Product Code: " + productCode + "\nProduct Name: "
									+ productName + "\nCost Price: " + costPrice + "\nSell Price: " + sellPrice
									+ "\nBrand: " + brand);
				}
			});

			removeButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// Perform the remove operation and update the results in the JTextArea
					String productCode = productCodeTextField.getText();

					// Remove from SQL database (replace with your actual database connection
					// details)
					removeProductFromDatabase(productCode);

					// Update the action log JTextArea
					updateActionLog(actionLogTextAreaProduct,
							"Product removed from database:\n" + "Product Code: " + productCode);
				}
			});

			// Create the "View Stocks" panel with a JTable and search functionality
			JPanel viewcurrentstockPanel = new JPanel();
			mainTabbedPane.addTab("Current Stocks", null, viewcurrentstockPanel, null);
			viewcurrentstockPanel.setBackground(new Color(0, 0, 153));
			viewcurrentstockPanel.setLayout(new BorderLayout());

			// Search Text Box with Button
			JPanel searchPanel = new JPanel();
			searchPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
			searchPanel.setBackground(new Color(255, 204, 0));
			JTextField searchTextField = new JTextField(10);
			JButton searchButton = new JButton("Search");
			JButton updateButton = new JButton("Update"); // Add the Update button

			searchPanel.add(searchTextField);
			searchPanel.add(searchButton);
			searchPanel.add(updateButton); // Add the Update button

			// Add ActionListener to the Update button
			updateButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// Perform the update operation and refresh the results in the JTable
					refreshcurrentstockTable(currentstockTableModel);
				}
			});

			viewcurrentstockPanel.add(searchPanel, BorderLayout.NORTH);

			// Add a titled border to the "View Stocks" panel
			viewcurrentstockPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "View Stocks",
					TitledBorder.LEFT, TitledBorder.TOP, null, new Color(255, 204, 0)));

			viewcurrentstockPanel.add(searchPanel, BorderLayout.NORTH);
			currentstockTable = new JTable(currentstockTableModel);
			currentstockTable.setBackground(new Color(102, 255, 255));
			viewcurrentstockPanel.add(new JScrollPane(currentstockTable), BorderLayout.CENTER);

			searchButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// Perform the search operation and update the results in the JTable
					String searchTerm = searchTextField.getText();
					searchProductIDAndMoveToTop(currentstockTableModel, searchTerm);
				}
			});

		    JPanel employeePanel = new JPanel();
		    employeePanel.setBackground(new Color(0, 0, 153));
		    employeePanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Employees",
		            TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 204, 0)));
		    mainTabbedPane.addTab("Employees", null, employeePanel, null);
		    employeePanel.setLayout(new BorderLayout(0, 0));
		    
		        // Initialize employeeTable with a default model
		        employeeTable = new JTable(new DefaultTableModel(new Object[][]{}, new Object[]{"Name", "Phone", "Email", "Employee ID"}));

		        JScrollPane scrollPane_2 = new JScrollPane(employeeTable);
		        employeePanel.add(scrollPane_2);
		    } catch (SQLException e1) {
		        e1.printStackTrace();
		    }

		JPanel logoutPanel = new JPanel();
		logoutPanel.setBackground(new Color(0, 0, 102));

		LineBorder lineBorder = new LineBorder(new Color(250, 204, 0), 2);


		TitledBorder titledBorder = new TitledBorder(lineBorder, "Logout", TitledBorder.LEFT, TitledBorder.TOP,
		        new Font("Arial", Font.BOLD, 14), new Color(255, 255, 255));


		CompoundBorder compoundBorder = new CompoundBorder(lineBorder, titledBorder);


		logoutPanel.setBorder(compoundBorder);

		mainTabbedPane.addTab("Logout", null, logoutPanel, null);

		JLabel logoutLabel = new JLabel("Are you sure you want to log out?");
		logoutLabel.setBackground(Color.WHITE);
		logoutLabel.setOpaque(true);  // Set the label to be opaque
		logoutLabel.setBounds(156, 113, 273, 86);
		logoutLabel.setFont(new Font("Montserrat Medium", Font.BOLD, 12));
		logoutLabel.setForeground(new Color(0, 0, 153));
		logoutLabel.setHorizontalAlignment(SwingConstants.CENTER);

		LineBorder labelBorder = new LineBorder(new Color(250, 204, 0), 2);

		logoutLabel.setBorder(labelBorder);


		JButton logoutButton = new JButton("Logout");
		logoutButton.setBounds(250, 208, 85, 23);
		logoutPanel.setLayout(null);

		logoutPanel.add(logoutLabel);
		logoutPanel.add(logoutButton);

		// Add action listener to the logout button
		logoutButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				performLogout();
			}
		});
	}

	private void performLogout() {

		dispose();

		SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
	}

	private void updateActionLog(JTextArea actionLogTextArea, String log) {
		// Append the new log to the existing text
		actionLogTextArea.append(log + "\n");

		// Ensure the last entry is visible (scroll to the bottom)
		actionLogTextArea.setCaretPosition(actionLogTextArea.getDocument().getLength());
	}

	private void refreshcurrentstockTable(DefaultTableModel currentstockTableModel) {

		currentstockTableModel.setRowCount(0);

		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory",
				"postgres", "143puddiepie")) {
			String query = "SELECT * FROM currentstock";
			try (PreparedStatement preparedStatement = connection.prepareStatement(query);
					ResultSet resultSet = preparedStatement.executeQuery()) {

				// Populate the table model with retrieved data
				while (resultSet.next()) {
					// Assuming your_stock_table has columns "column1", "column2", etc.
					Object[] rowData = { resultSet.getString("productcode"), resultSet.getObject("productname"),
							resultSet.getObject("quantity"), resultSet.getObject("pid"),
							// Add more columns as needed
					};
					currentstockTableModel.addRow(rowData);
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			// Handle the exception appropriately (e.g., show an error message)
		}
	}

	private void insertProductToDatabase(String productCode, String productName, String costPrice, String sellPrice,
			String brand) {

		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory",
				"postgres", "143puddiepie")) {
			String sql = "INSERT INTO products (productcode, productname, costprice, sellprice, phonebrand) VALUES (?, ?, ?, ?, ?)";
			try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
				preparedStatement.setString(1, productCode);
				preparedStatement.setString(2, productName);
				preparedStatement.setString(3, costPrice);
				preparedStatement.setString(4, sellPrice);
				preparedStatement.setString(5, brand);
				preparedStatement.executeUpdate();
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

	}

	private void removeProductFromDatabase(String productCode) {

		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory",
				"postgres", "143puddiepie")) {
			String sql = "DELETE FROM currentstock WHERE productcode = ?";
			try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
				preparedStatement.setString(1, productCode);
				preparedStatement.executeUpdate();
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private void searchProductIDAndMoveToTop(DefaultTableModel model, String searchTerm) {
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory",
				"postgres", "143puddiepie")) {
			String query = "SELECT * FROM currentstock WHERE productcode = ?";
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setString(1, searchTerm);

				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					if (resultSet.next()) {
						// Move the row to the top
						Vector<Object> rowData = new Vector<>();
						for (int col = 1; col <= model.getColumnCount(); col++) {
							rowData.add(resultSet.getObject(col));
						}
						model.insertRow(0, rowData);
					}
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Product ID not found", "Search Result",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new Main().setVisible(true));
	}

	public JTabbedPane getMainTabbedPane() {
		return mainTabbedPane;
	}

	public void setMainTabbedPane(JTabbedPane mainTabbedPane) {
		this.mainTabbedPane = mainTabbedPane;
	}

	public JTabbedPane getEmployeesTabbedPane() {
		return employeeTabbedPane;
	}

	public void setEmployeesTabbedPane(JTabbedPane employeeTabbedPane) {
		this.employeeTabbedPane = employeeTabbedPane;
	}

	public JTable getCurrentstockTable() {
		return currentstockTable;
	}

	public void setCurrentstockTable(JTable currentstockTable) {
		this.currentstockTable = currentstockTable;
	}
}