import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main extends JFrame {

    private JTabbedPane mainTabbedPane;
    private JTabbedPane employeesTabbedPane;
    private JTabbedPane purchaseinfoTable;
    private JTabbedPane currentstockTable;
    private JTabbedPane customersTable;
    

    public Main() {
        initializeUI();
        fetchInitialDataFromDatabase();
    }

    private void fetchInitialDataFromDatabase() {
		// Fetch initial data for tables from the database and update table models
        fetchpurchaseinfoDataFromDatabase((DefaultTableModel) purchaseinfoTable.getModel());
        fetchcurrentstockDataFromDatabase((DefaultTableModel) currentstockTable.getModel());
        fetchcustomersDataFromDatabase((DefaultTableModel) customersTable.getModel());
    }
    
    private void fetchpurchaseinfoDataFromDatabase(DefaultTableModel model) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "SELECT * FROM purchaseinfo";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getString("purchaseid"),
                            resultSet.getString("suppliercode"),
                            resultSet.getString("productcode"),
                            resultSet.getString("date"),
                            resultSet.getInt("quantity"),
                            resultSet.getString("totalcost")
                    };
                    model.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void fetchcurrentstockDataFromDatabase(DefaultTableModel model) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "SELECT * FROM currentstock";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getString("productname"),
                            resultSet.getInt("quantity"),
                            resultSet.getString("pid")
                    };
                    model.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void fetchcustomersDataFromDatabase(DefaultTableModel model) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "SELECT * FROM customers";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getString("customercode"),
                            resultSet.getString("fullname"),
                            resultSet.getString("address"),
                            resultSet.getString("contactnumber")
                    };
                    model.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    private void fetchproductsDataFromDatabase(DefaultTableModel model) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "SELECT * FROM customers";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getString("customercode"),
                            resultSet.getString("fullname"),
                            resultSet.getString("address"),
                            resultSet.getString("contactnumber")
                    };
                    model.addRow(rowData);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    private void initializeUI() {
        setTitle("Inventory Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 380);
        setLocationRelativeTo(null);

        mainTabbedPane = new JTabbedPane(JTabbedPane.LEFT);
        mainTabbedPane.setForeground(new Color(0, 0, 204));
        mainTabbedPane.setBackground(new Color(255, 204, 0));
        mainTabbedPane.setBorder(new LineBorder(new Color(0, 0, 204), 3));

        JPanel mainTabPanel = new JPanel();

        Vector<String> actionLogColumnNames = new Vector<>();
        actionLogColumnNames.add("Action");
        actionLogColumnNames.add("Details");

        Vector<Vector<String>> actionLogData = new Vector<>();
        DefaultTableModel actionLogTableModel = new DefaultTableModel(actionLogData, actionLogColumnNames);


        JTable actionLogTable = new JTable(actionLogTableModel);
        JScrollPane actionLogScrollPane = new JScrollPane(actionLogTable);
        actionLogScrollPane.setBounds(10, 10, 300, 200); // Adjust the bounds accordingly


        // Add a mouse listener to the action log table for future database connection
        actionLogTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Handle mouse click on action log table (e.g., display details or connect to the database)
                int selectedRow = actionLogTable.getSelectedRow();
                String Details = actionLogTableModel.getValueAt(selectedRow, 1).toString();
                JOptionPane.showMessageDialog(Main.this, Details, "Action Log Details", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        Object[][] purchaseinfoData = {
        };

        Object[] purchaseinfoColumnNames = {"Sales ID", "Supplier ID", "Product Code", "Date", "Quantity", "Total Cost"};
        
        DefaultTableModel purchaseinfoTableModel = new DefaultTableModel(purchaseinfoData, purchaseinfoColumnNames);

        
        Object[][] employeesData = {
                {"John Rhey", "123-456-7890", "john.rhey@example.com", "E001"},
                {"Jane TheVirgin", "987-654-3210", "jane.thevirgin@example.com", "E002"},
                {"Bob Marley", "555-123-4567", "bob.marley@example.com", "E003"}
        };

        Object[] employeesColumnNames = {"Name", "Phone", "Email", "Employee ID"};

        Object[][] currentstocktableData = {
        };

        Object[] columnNames = {"Product Name", "Quantity", "Product ID"};

        DefaultTableModel currentstockTableModel = new DefaultTableModel(currentstocktableData, columnNames);

        Object[][] customersData = {
        };
        Object[] customersColumnNames = {"Customer Code", "Full Name", "Address", "Contact Number"};

        DefaultTableModel customersTableModel = new DefaultTableModel(customersData, customersColumnNames);

        mainTabbedPane.addTab("Home", mainTabPanel);
        mainTabPanel.setLayout(new BorderLayout(0, 0));
        
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(new Color(255, 204, 0), 5, true));
        panel.setBackground(new Color(0, 0, 204));
        mainTabPanel.add(panel);
        panel.setLayout(null);
        
        JTextArea txtrBsitr = new JTextArea();
        txtrBsitr.setBounds(241, 59, 74, 23);
        txtrBsitr.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 15));
        txtrBsitr.setForeground(new Color(255, 204, 0));
        txtrBsitr.setBackground(new Color(0, 0, 204));
        txtrBsitr.setText("BSIT-2R1");
        panel.add(txtrBsitr);
        
        JTextArea txtrInventory = new JTextArea();
        txtrInventory.setText("INVENTORY");
        txtrInventory.setForeground(Color.WHITE);
        txtrInventory.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrInventory.setBackground(new Color(0, 0, 204));
        txtrInventory.setBounds(165, 93, 226, 46);
        panel.add(txtrInventory);
        
        JTextArea txtrManagen = new JTextArea();
        txtrManagen.setText("MANAGEMENT");
        txtrManagen.setForeground(Color.WHITE);
        txtrManagen.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrManagen.setBackground(new Color(0, 0, 204));
        txtrManagen.setBounds(138, 145, 280, 46);
        panel.add(txtrManagen);
        
        JTextArea txtrSystem = new JTextArea();
        txtrSystem.setText("SYSTEM");
        txtrSystem.setForeground(Color.WHITE);
        txtrSystem.setFont(new Font("Montserrat ExtraBold", Font.PLAIN, 35));
        txtrSystem.setBackground(new Color(0, 0, 204));
        txtrSystem.setBounds(201, 202, 154, 46);
        panel.add(txtrSystem);

        getContentPane().add(mainTabbedPane, BorderLayout.CENTER);
                
                        // Create the "Product" panel on the left
                        JPanel productPanel = new JPanel();
                        mainTabbedPane.addTab("Product", null, productPanel, null);
                        productPanel.setBackground(new Color(0, 0, 153));
                        productPanel.setForeground(new Color(0, 0, 139));
                        productPanel.setLayout(null);
                        
                                // Product Code Input Box with Label
                                JLabel productCodeLabel = new JLabel("Product Code:");
                                productCodeLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                productCodeLabel.setForeground(new Color(255, 204, 0));
                                productCodeLabel.setBounds(320, 20, 100, 20);
                                JTextField productCodeTextField = new JTextField();
                                productCodeTextField.setBounds(430, 20, 80, 20);
                                
                                        // Product Name Input Box with Label
                                        JLabel productNameLabel = new JLabel("Product Name:");
                                        productNameLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                        productNameLabel.setForeground(new Color(255, 204, 0));
                                        productNameLabel.setBounds(320, 50, 100, 20);
                                        JTextField productNameTextField = new JTextField();
                                        productNameTextField.setBounds(430, 50, 80, 20);
                                        
                                                // Cost Price Input Box with Label
                                                JLabel costPriceLabel = new JLabel("Cost Price:");
                                                costPriceLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                costPriceLabel.setForeground(new Color(255, 204, 0));
                                                costPriceLabel.setBounds(320, 80, 100, 20);
                                                JTextField costPriceTextField = new JTextField();
                                                costPriceTextField.setBounds(430, 80, 80, 20);
                                                
                                                        // Sell Price Input Box with Label
                                                        JLabel sellPriceLabel = new JLabel("Sell Price:");
                                                        sellPriceLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                        sellPriceLabel.setForeground(new Color(255, 204, 0));
                                                        sellPriceLabel.setBounds(320, 111, 100, 20);
                                                        JTextField sellPriceTextField = new JTextField();
                                                        sellPriceTextField.setBounds(430, 111, 80, 20);
                                                        
                                                                // Brand Input Box with Label
                                                                JLabel brandLabel = new JLabel("Brand:");
                                                                brandLabel.setFont(new Font("Montserrat Medium", Font.PLAIN, 11));
                                                                brandLabel.setForeground(new Color(255, 204, 0));
                                                                brandLabel.setBounds(320, 140, 100, 20);
                                                                JTextField brandTextField = new JTextField();
                                                                brandTextField.setBounds(430, 140, 80, 20);
                                                                
                                                                        // Buttons
                                                                        JButton addButton = new JButton("Add");
                                                                        addButton.setFont(new Font("Montserrat SemiBold", Font.PLAIN, 11));
                                                                        addButton.setBounds(372, 171, 60, 25);
                                                                        
                                                                                JButton removeButton = new JButton("Remove");
                                                                                removeButton.setFont(new Font("Montserrat SemiBold", Font.PLAIN, 11));
                                                                                removeButton.setBounds(440, 170, 100, 25);
                                                                                
                                                                                        productPanel.add(productCodeLabel);
                                                                                        productPanel.add(productCodeTextField);
                                                                                        productPanel.add(productNameLabel);
                                                                                        productPanel.add(productNameTextField);
                                                                                        productPanel.add(costPriceLabel);
                                                                                        productPanel.add(costPriceTextField);
                                                                                        productPanel.add(sellPriceLabel);
                                                                                        productPanel.add(sellPriceTextField);
                                                                                        productPanel.add(brandLabel);
                                                                                        productPanel.add(brandTextField);
                                                                                        productPanel.add(addButton);
                                                                                        productPanel.add(removeButton);
                                                                                        
                                                                                                // Add a titled border to the "Product" panel
                                                                                                productPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 2), "Product", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(255, 255, 255)));
                                                                                                
                                                                                                        // Text area to display action log
                                                                                                        JTextArea actionLogTextAreaProduct = new JTextArea(5, 20);
                                                                                                        actionLogTextAreaProduct.setBackground(Color.LIGHT_GRAY);
                                                                                                        actionLogTextAreaProduct.setBounds(36, 18, 240, 277);
                                                                                                        productPanel.add(actionLogTextAreaProduct);
                                                                                                        actionLogTextAreaProduct.setEditable(false);
                                                                                                        
                                                                                                                addButton.addActionListener(new ActionListener() {
                                                                                                                    @Override
                                                                                                                    public void actionPerformed(ActionEvent e) {
                                                                                                                        // Perform the add operation and update the results in the JTextArea
                                                                                                                        String productCode = productCodeTextField.getText();
                                                                                                                        String productName = productNameTextField.getText();
                                                                                                                        String costPrice = costPriceTextField.getText();
                                                                                                                        String sellPrice = sellPriceTextField.getText();
                                                                                                                        String brand = brandTextField.getText();
                                                                                                        
                                                                                                                        // Insert into SQL database (replace with your actual database connection details)
                                                                                                                        insertProductToDatabase(productCode, productName, costPrice, sellPrice, brand);
                                                                                                        
                                                                                                                        updateActionLog(actionLogTableModel, "Product added to database:\n" +
                                                                                                                                "Product Code: " + productCode +
                                                                                                                                "\nProduct Name: " + productName +
                                                                                                                                "\nCost Price: " + costPrice +
                                                                                                                                "\nSell Price: " + sellPrice +
                                                                                                                                "\nBrand: " + brand);
                                                                                                                    }
                                                                                                                });
                                                                                                                
                                                                                                                        removeButton.addActionListener(new ActionListener() {
                                                                                                                            @Override
                                                                                                                            public void actionPerformed(ActionEvent e) {
                                                                                                                                // Perform the remove operation and update the results in the JTextArea
                                                                                                                                String productCode = productCodeTextField.getText();
                                                                                                                
                                                                                                                                // Remove from SQL database (replace with your actual database connection details)
                                                                                                                                removeProductFromDatabase(productCode);
                                                                                                                
                                                                                                                                updateActionLog(actionLogTableModel, "Product removed from database:\n" +
                                                                                                                                        "Product Code: " + productCode);
                                                                                                                            }
                                                                                                                        });
                        
                             // Create the "Sales" panel with a JTable
                                JPanel purchaseinfoPanel = new JPanel();
                                purchaseinfoPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Sales", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
                                mainTabbedPane.addTab("Sales", null, purchaseinfoPanel, null);
                                purchaseinfoPanel.setBackground(new Color(0, 0, 153));
                                purchaseinfoPanel.setLayout(new BorderLayout(0, 0));
                                
                                        JTable purchaseinfoTable = new JTable(new DefaultTableModel(purchaseinfoData, purchaseinfoColumnNames));
                                        purchaseinfoTable.setBackground(new Color(153, 255, 255));
                                        JScrollPane scrollPane = new JScrollPane(purchaseinfoTable);
                                        scrollPane.setBackground(new Color(153, 255, 255));
                                        purchaseinfoPanel.add(scrollPane);
                
                        // Create the "View Stocks" panel with a JTable and search functionality
                        JPanel viewcurrentstockPanel = new JPanel();
                        mainTabbedPane.addTab("Current Stocks", null, viewcurrentstockPanel, null);
                        viewcurrentstockPanel.setBackground(new Color(0, 0, 153));
                        viewcurrentstockPanel.setLayout(new BorderLayout());
                        
                                // Search Text Box with Button
                        JPanel searchPanel = new JPanel();
                        searchPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
                        searchPanel.setBackground(new Color(255, 204, 0));
                        JTextField searchTextField = new JTextField(10);
                        JButton searchButton = new JButton("Search");
                        JButton updateButton = new JButton("Update"); // Add the Update button

                        searchPanel.add(searchTextField);
                        searchPanel.add(searchButton);
                        searchPanel.add(updateButton); // Add the Update button

                        
                        // Add ActionListener to the Update button
                        updateButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
								// Perform the update operation and refresh the results in the JTable
                                refreshcurrentstockTable(currentstockTableModel);
                            }
                        });

                        viewcurrentstockPanel.add(searchPanel, BorderLayout.NORTH);
                                        
                                                // Add a titled border to the "View Stocks" panel
                        			viewcurrentstockPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "View Stocks", TitledBorder.LEFT, TitledBorder.TOP, null, new Color(255, 204, 0)));
                                                
                                                        viewcurrentstockPanel.add(searchPanel, BorderLayout.NORTH);
                                                        JTable currentstockTable = new JTable(currentstockTableModel);
                                                        currentstockTable.setBackground(new Color(102, 255, 255));
                                                        viewcurrentstockPanel.add(new JScrollPane(currentstockTable), BorderLayout.CENTER);
                                                        
                                                                searchButton.addActionListener(new ActionListener() {
                                                                    @Override
                                                                    public void actionPerformed(ActionEvent e) {
                                                                        // Perform the search operation and update the results in the JTable
                                                                        String searchTerm = searchTextField.getText();
                                                                        searchProductIDAndMoveToTop(currentstockTableModel, searchTerm);
                                                                    }
                                                                });
                
                     // Create the "Customers" panel with a JTable
                        JPanel customersPanel = new JPanel();
                        customersPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Customers", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 204, 0)));
                        mainTabbedPane.addTab("Customers", null, customersPanel, null);
                        customersPanel.setBackground(new Color(0, 0, 204));
                        customersPanel.setLayout(new BorderLayout(0, 0));
                        JTable customersTable = new JTable(customersTableModel);
                        customersTable.setBackground(new Color(102, 255, 255));
                        JScrollPane scrollPane_1 = new JScrollPane(customersTable);
                        customersPanel.add(scrollPane_1);
        
                // Create the "Employees" panel with a JTable
                JPanel employeesPanel = new JPanel();
                employeesPanel.setBackground(new Color(0, 0, 153));
                employeesPanel.setBorder(new TitledBorder(new LineBorder(new Color(255, 204, 0), 3), "Employees", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 204, 0)));
                mainTabbedPane.addTab("Employees", null, employeesPanel, null);
                        employeesPanel.setLayout(new BorderLayout(0, 0));
                
                        JTable employeesTable = new JTable(new DefaultTableModel(employeesData, employeesColumnNames));
                        JScrollPane scrollPane_2 = new JScrollPane(employeesTable);
                        employeesPanel.add(scrollPane_2);
    }

    private void updateActionLog(DefaultTableModel actionLogTableModel, String log) {
        Vector<String> row = new Vector<>();
        row.add(log.split("\n")[0]);  // Action
        row.add(log.substring(log.indexOf("\n") + 1));  // Details
        actionLogTableModel.addRow(row);
    }
    
    private void refreshcurrentstockTable(DefaultTableModel currentstockTableModel) {
        // TODO: Implement logic to refresh the stocks table data
        // Fetch updated data from your data source and update the table model

        // For demonstration purposes, I'm clearing the existing data and adding dummy data.
        currentstockTableModel.setRowCount(0);

        // Dummy data (replace this with actual data retrieval logic)
        Object[][] updatedStocksData = {
        };

        for (Object[] rowData : updatedStocksData) {
            currentstockTableModel.addRow(rowData);
        }
    }

    private void insertProductToDatabase(String productCode, String productName, String costPrice, String sellPrice, String brand) {
      
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "INSERT INTO products (productcode, productname, costprice, sellprice, phonebrand) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, productCode);
                preparedStatement.setString(2, productName);
                preparedStatement.setString(3, costPrice);
                preparedStatement.setString(4, sellPrice);
                preparedStatement.setString(5, brand);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    private void removeProductFromDatabase(String productCode) {

        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Inventory", "postgres", "143puddiepie")) {
            String sql = "DELETE FROM products WHERE productcode = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, productCode);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void searchProductIDAndMoveToTop(DefaultTableModel model, String searchTerm) {
        for (int row = 0; row < model.getRowCount(); row++) {
            Object value = model.getValueAt(row, 2); // Assuming Product ID is in the third column
            if (value != null && value.toString().equals(searchTerm)) {
                // Move the row to the top
                Vector<Object> rowData = new Vector<>();
                for (int col = 0; col < model.getColumnCount(); col++) {
                    rowData.add(model.getValueAt(row, col));
                }
                model.removeRow(row);
                model.insertRow(0, rowData);
                return; // Assuming there is only one occurrence of the Product ID
            }
        }
        JOptionPane.showMessageDialog(this, "Product ID not found", "Search Result", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}